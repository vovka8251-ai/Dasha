package com.dasha;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class DashaBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d("Dasha", "Телефон загрузился, запускаю Dasha...");
            Intent serviceIntent = new Intent(context, DashaForegroundService.class);
            context.startForegroundService(serviceIntent);
        }
    }
}
