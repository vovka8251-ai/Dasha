package com.dasha;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.util.Log;
import android.os.Build;

public class DashaAccessibilityService extends AccessibilityService {
    private static final String TAG = "Dasha";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        StringBuilder sb = new StringBuilder();
        traverseNode(root, sb);
        
        if (sb.length() > 0) {
            Log.d(TAG, "Вижу: " + sb.toString());
        }
    }

    private void traverseNode(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node.getText() != null && node.getText().length() > 0) {
            sb.append("[").append(node.getText()).append("] ");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) traverseNode(child, sb);
        }
    }

    public void clickByText(String target) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            findAndClick(root, target);
        }
    }

    private void findAndClick(AccessibilityNodeInfo node, String target) {
        if (node.getText() != null && node.getText().toString().equalsIgnoreCase(target)) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            return;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) findAndClick(child, target);
        }
    }

    public void swipeUp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(540, 1800);
            path.lineTo(540, 600);
            
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 300));
            
            dispatchGesture(builder.build(), null, null);
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Dasha прервана");
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS |
                    AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY |
                    AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        info.notificationTimeout = 100;
        setServiceInfo(info);
        Log.d(TAG, "Dasha подключена и готова");
    }
}
