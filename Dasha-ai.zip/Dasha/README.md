# Dasha - AI Assistant

Personal Android assistant by vovka8251-ai

## Features
- Foreground Service (always running)
- Accessibility Service (screen control)
- Auto-start on boot

## Build
Automatic APK build via GitHub Actions
